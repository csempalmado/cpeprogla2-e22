#include <iostream>
#include <cmath>
using namespace std;



int main (){
	int x, y, z;
	
	cout<<"Enter Hashmat's Army: ";
	cin>>x;
	cout<<"Enter Opponent's Army: ";
	cin>>y;
	z=x-y;
	cout<<"Difference: "<<abs(z);

	
	return 0;
}
